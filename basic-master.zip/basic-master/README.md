# basic

Tasks
----------
Dropdowns
- main nav
Side bar nav
- highlight
Detail View
Listing View
Staff Position Filter Search
Homepage
 - slider

JS
-----
- sliders
- Sidebar JS
- filter Search for staff

